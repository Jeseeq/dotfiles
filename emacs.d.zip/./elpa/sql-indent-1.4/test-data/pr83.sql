SELECT
  Column1,
  Column2,
  -- this is FROM a blog WHERE useful stuff was described
  Column3,
  Column4
  FROM Atable;
