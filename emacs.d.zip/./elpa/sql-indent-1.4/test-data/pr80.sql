drop function if exists test;

-- local variables:
-- mode: sql
-- sql-product: postgres
-- end:
