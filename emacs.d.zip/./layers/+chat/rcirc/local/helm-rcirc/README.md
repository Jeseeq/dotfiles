helm-rcirc
==========

An Helm interface for rcirc
