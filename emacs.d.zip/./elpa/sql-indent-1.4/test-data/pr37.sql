create or replace package my_user.my_wonderfull_package as
  function my_amazing_func return number;
end my_wonderfull_package;
/

-- Local Variables:
-- mode: sql
-- mode: sqlind-minor
-- tab-width: 2
-- indent-tabs-mode: nil
-- sql-product: oracle
-- End:
